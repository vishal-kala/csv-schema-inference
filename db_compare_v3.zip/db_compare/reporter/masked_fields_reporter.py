import json
import traceback

from openpyxl import Workbook
from openpyxl.styles import Border, Side, Font, PatternFill, Alignment

CELL_BORDER = Border(
    left=Side(border_style='thin', color='000000'),
    right=Side(border_style='thin', color='000000'),
    top=Side(border_style='thin', color='000000'),
    bottom=Side(border_style='thin', color='000000')
)

REGULAR_FONT = Font(size=11, name='Calibri', bold=False)
BOLD_FONT = Font(size=12, name='Calibri', bold=True)
BOLD_FONT_LARGE = Font(size=13, name='Calibri', bold=True)
GREY_FILL = PatternFill(start_color='D9D9D9', end_color='D9D9D9', fill_type='solid')
ALIGN_CENTER = Alignment(horizontal='left')

REPORT_ALL = True


class MaskedFieldsReporter:
    def __init__(self):
        print(f'Initializing Masked Fields Reporter')

        self.workbook = None
        self.worksheet = None
        self.row_number = None

    def write_data_to_excel(self, list_data, xls_file_name):
        self.row_number = 1
        self.workbook = Workbook()
        self.worksheet = self.workbook.create_sheet('Masked Fields Report')

        for data in list_data:
            table_name = data['table']
            table_header = ['Table Name', table_name]

            print(f'Writing data for table {table_name}')

            self.add_header_row(table_header)
            self.add_blank_row()

            result = data['result']

            column_headers = ['Column Name', 'Count', 'Result']
            self.add_sub_header_row(column_headers)

            # Write Column Data
            for item in result:
                column_values = [item['column'], item['count'], item['result']]
                self.add_data_row(column_values)

            self.add_blank_row()
            self.add_blank_row()

        self.adjust_width()

        self.workbook.remove(self.workbook.active)
        self.workbook.save(xls_file_name)
        print(f'Successfully written data in the {xls_file_name} file')

    def increment_row_number(self):
        self.row_number = self.row_number + 1

    def add_blank_row(self):
        self.increment_row_number()

        for i, value in enumerate([''], start=1):
            self.worksheet.cell(row=self.row_number, column=i, value=value)

    def add_bold_data_row(self, row_data):
        self.increment_row_number()

        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT

    def add_data_row(self, row_data):
        self.increment_row_number()

        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = REGULAR_FONT

    def add_header_row(self, row_data):
        self.increment_row_number()

        # Add a row of cells with the style applied
        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT_LARGE
            cell.fill = GREY_FILL
            cell.alignment = ALIGN_CENTER

    def add_sub_header_row(self, row_data):
        self.increment_row_number()

        # Add a row of cells with the style applied
        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT
            cell.fill = GREY_FILL
            cell.alignment = ALIGN_CENTER

    # To adjust the column length
    def adjust_width(self):
        print(f'Adjusting column widths')

        for column in self.worksheet.columns:
            max_length = 0
            column_name = column[0].column_letter  # Get the column name
            for cell in column:
                try:  # Necessary to avoid error on empty cells
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except Exception as e:
                    traceback.print_exc()
                    pass

            adjusted_width = (max_length + 2) * 1.2
            self.worksheet.column_dimensions[column_name].width = adjusted_width
