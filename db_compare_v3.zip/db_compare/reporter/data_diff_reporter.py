import traceback

from openpyxl import Workbook
from openpyxl.styles import Border, Side, Font, PatternFill, Alignment

CELL_BORDER = Border(
    left=Side(border_style='thin', color='000000'),
    right=Side(border_style='thin', color='000000'),
    top=Side(border_style='thin', color='000000'),
    bottom=Side(border_style='thin', color='000000')
)

REGULAR_FONT = Font(size=11, name='Calibri', bold=False)
BOLD_FONT = Font(size=12, name='Calibri', bold=True)
BOLD_FONT_LARGE = Font(size=13, name='Calibri', bold=True)
GREY_FILL = PatternFill(start_color='D9D9D9', end_color='D9D9D9', fill_type='solid')
GREY_FILL_LIGHT = PatternFill(start_color='F3F3F3', end_color='F3F3F3', fill_type='solid')
ALIGNMENT = Alignment(horizontal='left')
SECTION_FONT = Font(size=13, name='Calibri', bold=True, underline='double')


class DataDiffReporter:
    def __init__(self):
        print(f'Initializing Data Diff Reporter')

        self.workbook = None
        self.worksheet = None
        self.row_number = None

    def write_diff_to_excel(self, list_data_diff, xls_file_name):
        self.row_number = 1
        self.workbook = Workbook()
        self.worksheet = self.workbook.create_sheet('Schema Diff Report')

        for data_diff in list_data_diff:
            result_id = data_diff['result_id']
            result_id_row = ['Result ID', result_id]

            self.add_header_row(result_id_row)

            columns = data_diff['columns']

            oracle_only_rows = data_diff['oracle_only_rows']
            if len(oracle_only_rows) > 0:
                self.add_blank_row()
                self.add_section_row(['Oracle Only Rows'])
                self.add_sub_header_row(columns)

                for json_row in oracle_only_rows:
                    xls_row = []
                    for col in columns:
                        xls_row.append(json_row[col])
                    self.add_data_row(xls_row)

            snowflake_only_rows = data_diff['snowflake_only_rows']
            if len(snowflake_only_rows) > 0:
                self.add_blank_row()
                self.add_section_row(['Snowflake Only Rows'])
                self.add_sub_header_row(columns)

                for json_row in snowflake_only_rows:
                    xls_row = []
                    for col in columns:
                        xls_row.append(json_row[col])
                    self.add_data_row(xls_row)

            same_rows = data_diff['same_rows']
            if len(same_rows) > 0:
                self.add_blank_row()
                self.add_section_row(['Common Rows'])
                self.add_sub_header_row(columns)

                for json_row in same_rows:
                    xls_row = []
                    for col in columns:
                        xls_row.append(json_row[col])
                    self.add_data_row(xls_row)

            diff_rows = data_diff['diff_rows']
            if len(diff_rows) > 0:
                self.add_blank_row()
                self.add_section_row(['Differences'])

                # Get all column names
                list_columns = []
                for json_row in diff_rows:
                    list_columns = list_columns + list(json_row.keys())

                list_columns = list(set(list_columns))
                list_columns.sort()
                list_columns.remove('record_id')

                column_headers = ['']

                for column in list_columns:
                    column_headers.append(column)
                    column_headers.append('__MERGE__')

                self.add_sub_header_row(column_headers)

                data_headers = ['Record Identifier']

                for column in list_columns:
                    data_headers.append(f'Oracle')
                    data_headers.append(f'Snowflake')

                self.add_sub_header_row(data_headers)

                for json_row in diff_rows:
                    xls_row = [json_row['record_id']]
                    for column in list_columns:
                        xls_row.append(json_row.get(column, {}).get('oracle'))
                        xls_row.append(json_row.get(column, {}).get('snowflake'))

                    self.add_data_row(xls_row)

                self.add_blank_row()
                self.add_blank_row()

        self.adjust_width()
        self.merge_cells()

        self.workbook.remove(self.workbook.active)
        self.workbook.save(xls_file_name)
        print(f'Successfully written data in the {xls_file_name} file')

    def increment_row_number(self):
        self.row_number = self.row_number + 1

    def add_blank_row(self):
        self.increment_row_number()

        for i, value in enumerate([''], start=1):
            self.worksheet.cell(row=self.row_number, column=i, value=value)

    def add_bold_data_row(self, row_data):
        self.increment_row_number()

        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT

    def add_data_row(self, row_data):
        self.increment_row_number()

        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = REGULAR_FONT

    def add_header_row(self, row_data):
        self.increment_row_number()

        # Add a row of cells with the style applied
        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT_LARGE
            cell.fill = GREY_FILL
            cell.alignment = ALIGNMENT

    def add_section_row(self, row_data):
        self.increment_row_number()

        # Add a row of cells with the style applied
        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.font = SECTION_FONT

    def add_sub_header_row(self, row_data):
        self.increment_row_number()

        # Add a row of cells with the style applied
        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT
            cell.fill = GREY_FILL_LIGHT
            cell.alignment = ALIGNMENT

    # To merge the cells
    def merge_cells(self):
        print(f'Merging cells')

        for row in self.worksheet.iter_rows():
            previous_cell = None
            for cell in row:
                if cell.value == '__MERGE__':
                    self.worksheet.merge_cells(f'{previous_cell.column_letter}{previous_cell.row}:'
                                               f'{cell.column_letter}{cell.row}')

                previous_cell = cell

    # To adjust the column length
    def adjust_width(self):
        print(f'Adjusting column widths')

        for column in self.worksheet.columns:
            max_length = 0
            column_name = column[0].column_letter  # Get the column name
            for cell in column:
                try:  # Necessary to avoid error on empty cells
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except Exception as e:
                    traceback.print_exc()
                    pass

            adjusted_width = (max_length + 2) * 1.2
            self.worksheet.column_dimensions[column_name].width = adjusted_width
