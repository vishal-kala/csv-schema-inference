import json
import traceback

from openpyxl import Workbook
from openpyxl.styles import Border, Side, Font, PatternFill, Alignment

CELL_BORDER = Border(
    left=Side(border_style='thin', color='000000'),
    right=Side(border_style='thin', color='000000'),
    top=Side(border_style='thin', color='000000'),
    bottom=Side(border_style='thin', color='000000')
)

REGULAR_FONT = Font(size=11, name='Calibri', bold=False)
BOLD_FONT = Font(size=12, name='Calibri', bold=True)
BOLD_FONT_LARGE = Font(size=13, name='Calibri', bold=True)
GREY_FILL = PatternFill(start_color='D9D9D9', end_color='D9D9D9', fill_type='solid')
ALIGN_CENTER = Alignment(horizontal='left')


class SchemaDiffReporter:
    def __init__(self):
        print(f'Initializing Schema Diff Reporter')

        self.workbook = None
        self.worksheet = None
        self.row_number = None

    def write_diff_to_excel(self, list_data, xls_file_name):
        self.row_number = 1
        self.workbook = Workbook()
        self.worksheet = self.workbook.create_sheet('Schema Diff Report')

        for data in list_data:
            oracle_table_name = data['oracle_table']
            oracle_table_header = ['Oracle Table Name', oracle_table_name]

            snow_table_name = data['snowflake_table']
            snow_table_header = ['Snowflake Table Name', snow_table_name]

            print(f'Writing data for table {oracle_table_name} and {snow_table_name}')

            self.add_header_row(oracle_table_header)
            self.add_header_row(snow_table_header)

            table_level_result = data['result']

            if table_level_result:
                result_row = ['Result', table_level_result]
                self.add_bold_data_row(result_row)
                self.add_blank_row()
                self.add_blank_row()

                continue

            self.add_blank_row()

            columns = data['columns']
            column_headers = ['Column Name', 'Oracle Data Type', 'Oracle Is Nullable',
                              'Snowflake Data Type', 'Snowflake Is Nullable', 'Result']
            self.add_sub_header_row(column_headers)

            # Write Column Data
            for column in columns:
                column_name = column['name']
                orcl_data_type = column['orcl_data_type']
                orcl_nullable = column['orcl_nullable']
                sf_data_type = column['snow_data_type']
                sf_nullable = column['snow_nullable']
                diff_result = column['result']

                column_values = [column_name, orcl_data_type, orcl_nullable, sf_data_type, sf_nullable, diff_result]
                self.add_data_row(column_values)

            self.add_blank_row()
            self.add_blank_row()

        self.adjust_width()

        self.workbook.remove(self.workbook.active)
        self.workbook.save(xls_file_name)
        print(f'Successfully written data in the {xls_file_name} file')

    def increment_row_number(self):
        self.row_number = self.row_number + 1

    def add_blank_row(self):
        self.increment_row_number()

        for i, value in enumerate([''], start=1):
            self.worksheet.cell(row=self.row_number, column=i, value=value)

    def add_bold_data_row(self, row_data):
        self.increment_row_number()

        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT

    def add_data_row(self, row_data):
        self.increment_row_number()

        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = REGULAR_FONT

    def add_header_row(self, row_data):
        self.increment_row_number()

        # Add a row of cells with the style applied
        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT_LARGE
            cell.fill = GREY_FILL
            cell.alignment = ALIGN_CENTER

    def add_sub_header_row(self, row_data):
        self.increment_row_number()

        # Add a row of cells with the style applied
        for i, value in enumerate(row_data, start=1):
            cell = self.worksheet.cell(row=self.row_number, column=i, value=value)
            cell.border = CELL_BORDER
            cell.font = BOLD_FONT
            cell.fill = GREY_FILL
            cell.alignment = ALIGN_CENTER

    # To adjust the column length
    def adjust_width(self):
        print(f'Adjusting column widths')

        for column in self.worksheet.columns:
            max_length = 0
            column_name = column[0].column_letter  # Get the column name
            for cell in column:
                try:  # Necessary to avoid error on empty cells
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except Exception as e:
                    traceback.print_exc()
                    pass

            adjusted_width = (max_length + 2) * 1.2
            self.worksheet.column_dimensions[column_name].width = adjusted_width
