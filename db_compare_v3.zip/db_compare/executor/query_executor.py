import decimal
import numbers
import yaml
import os
from datetime import datetime, date


class QueryExecutor:
    def __init__(self, config_file):
        print(f'Executor initializing using config file: {config_file}')
        self.config_file = config_file

        self.connection = None
        self.schema_name = None

        with open(self.config_file) as file:
            self.config = yaml.safe_load(os.path.expandvars(file.read()))

    def execute_query(self, query):
        print(f'Query: {query}')

        cursor = self.connection.cursor()
        cursor.execute(query)

        # Fetch results as list of dictionaries
        rows = cursor.fetchall()
        columns = [i[0] for i in cursor.description]

        result = []
        for row in rows:
            row_dict = {}
            for i, value in enumerate(row):
                if isinstance(value, datetime) or isinstance(value, date):
                    row_dict[columns[i]] = value.strftime('%Y-%m-%d %H:%M:%S.%f')
                elif isinstance(value, decimal.Decimal) or isinstance(value, numbers.Number):
                    row_dict[columns[i]] = str(value)
                else:
                    row_dict[columns[i]] = value

            result.append(row_dict)

        cursor.close()

        print(f'Columns: {columns}')
        print(f'Result: {result}')

        return columns, result

    def get_schema_name(self, input_table_name):
        if '.' in input_table_name:
            return input_table_name.split('.')[0]

        return self.schema_name

    def get_table_name(self, input_table_name):
        if '.' in input_table_name:
            return input_table_name.split('.')[1]

        return input_table_name

