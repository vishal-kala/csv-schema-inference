import cx_Oracle
import pandas as pd


from migration_validator.db_compare.executor.query_executor import QueryExecutor


class OracleQueryExecutor(QueryExecutor):
    def open_connection(self):
        host = self.config.get('database', {}).get('host')
        port = self.config.get('database', {}).get('port')
        service_name = self.config.get('database', {}).get('service_name')
        user = self.config.get('database', {}).get('username')
        password = self.config.get('database', {}).get('password')

        print(f'Oracle: Attempting to connect to {host}:{port}/{service_name}@{user}')

        dsn_str = cx_Oracle.makedsn(host, port, service_name=service_name)

        # Connect to the database
        connection = cx_Oracle.connect(user=user, password=password, dsn=dsn_str)

        self.connection = connection
        self.schema_name = self.config.get('database', {}).get('schema')

        print(f'Oracle: Connection successful')

    def close_connection(self):
        self.connection.close()
        print(f'Oracle: Connection Closed successfully')

    def execute_query_pandas(self, query):
        cursor = self.connection.cursor()
        cursor.execute(query)

        df = pd.read_sql(cursor.statement, con=self.connection)

        cursor.close()

        df.head()

        return df

    def fetch_primary_key(self, table_name):
        query = f"SELECT TABLE_NAME, COLUMN_NAME FROM ALL_CONS_COLUMNS WHERE CONSTRAINT_NAME = " \
                f"(SELECT CONSTRAINT_NAME FROM ALL_CONSTRAINTS " \
                f"WHERE OWNER = '{self.schema_name}' AND TABLE_NAME = '{table_name}' AND CONSTRAINT_TYPE = 'P' )" \
                f"AND TABLE_NAME = '{table_name}' " \
                f"ORDER BY POSITION"

        return self.execute_query(query)

    def fetch_all_tables(self):
        query = f"SELECT OWNER, TABLE_NAME FROM ALL_TABLES WHERE OWNER = '{self.schema_name}'"

        return self.execute_query(query)

    def fetch_table_metadata(self, input_table_name):
        schema_name = self.get_schema_name(input_table_name)
        table_name = self.get_table_name(input_table_name)

        query = f"SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, DATA_LENGTH, NULLABLE " \
                f"FROM ALL_TAB_COLS WHERE OWNER = '{schema_name}' " \
                f"AND TABLE_NAME = '{table_name}' " \
                f"ORDER BY TABLE_NAME, COLUMN_NAME"

        return self.execute_query(query)


def unit_test():
    executor = OracleQueryExecutor('../config/oracle-config.yml')

    executor.open_connection()

    executor.fetch_primary_key('CLAIM_CDC')
    executor.execute_query(f'select CLAIMNUMBER from {executor.schema_name}.claim_cdc where rownum < 10')
    executor.execute_query(f'select cont from {executor.schema_name}.claim_cdc where rownum < 10')

    executor.fetch_all_tables()
    executor.fetch_table_metadata('CLAIM_CDC')

    executor.close_connection()


if __name__ == '__main__':
    unit_test()
