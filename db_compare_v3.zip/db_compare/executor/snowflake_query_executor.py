from snowflake.connector import connect
from migration_validator.db_compare.executor.query_executor import QueryExecutor


class SnowflakeQueryExecutor(QueryExecutor):
    def open_connection(self):
        user = self.config.get('database', {}).get('username')
        password = self.config.get('database', {}).get('password')
        account = self.config.get('database', {}).get('account')
        database = self.config.get('database', {}).get('database')
        schema = self.config.get('database', {}).get('schema')
        warehouse = self.config.get('database', {}).get('warehouse')
        role = self.config.get('database', {}).get('role')
        authenticator = self.config.get('database', {}).get('authenticator')

        print(f'Snowflake: Attempting to connect to {warehouse}//{account}/{database}@{user}')

        # Connect to the database
        if authenticator:
            connection = connect(
                user=user,
                authenticator=authenticator,
                account=account,
                database=database,
                schema=schema,
                warehouse=warehouse,
                role=role
            )
        else:
            connection = connect(
                user=user,
                password=password,
                account=account,
                database=database,
                schema=schema,
                warehouse=warehouse,
                role=role
            )
        self.connection = connection
        self.schema_name = self.config.get('database', {}).get('schema')

        print(f'Snowflake: Connection successful')

    def close_connection(self):
        self.connection.close()
        print(f'Snowflake: Connection Closed successfully')

    def execute_query_pandas(self, query):
        cursor = self.connection.cursor()
        cursor.execute(query)

        df = cursor.fetch_pandas_all()

        cursor.close()

        df.head()

        return df

    def fetch_table_metadata(self, input_table_name):
        schema_name = self.get_schema_name(input_table_name)
        table_name = self.get_table_name(input_table_name)

        query = f"SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, " \
                f"CHARACTER_MAXIMUM_LENGTH AS DATA_LENGTH, IS_NULLABLE AS NULLABLE " \
                f"FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '{schema_name}' " \
                f"AND TABLE_NAME = '{table_name}' " \
                f"ORDER BY TABLE_NAME, COLUMN_NAME"

        return self.execute_query(query)

    def fetch_all_tables(self):
        query = "SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES " \
                f"WHERE TABLE_SCHEMA = '{self.schema_name}'"

        return self.execute_query(query)


def unit_test():
    executor = SnowflakeQueryExecutor('../config/snowflake-config.yml')

    executor.open_connection()

    executor.fetch_all_tables()
    executor.fetch_table_metadata('CLAIMITEM')

    executor.close_connection()


if __name__ == '__main__':
    unit_test()
