import json
import yaml

from migration_validator.db_compare.executor.oracle_query_executor import OracleQueryExecutor
from migration_validator.db_compare.executor.snowflake_query_executor import SnowflakeQueryExecutor
from migration_validator.db_compare.reporter.data_diff_reporter import DataDiffReporter


def find_item_by_field(json_list, field_name, field_value):
    for item in json_list:
        if item.get(field_name) == field_value:
            return item
    return None


def read_yaml_file(yaml_file):
    with open(yaml_file) as file:
        return yaml.safe_load(file)


class QueryDiffer:
    def __init__(self, oracle_config_file, snowflake_config_file):
        self.oracle_config_file = oracle_config_file
        self.snowflake_config_file = snowflake_config_file

        self.oracle_executor = OracleQueryExecutor(self.oracle_config_file)
        self.snowflake_executor = SnowflakeQueryExecutor(self.snowflake_config_file)

    def open_connections(self):
        self.oracle_executor.open_connection()
        self.snowflake_executor.open_connection()

    def close_connections(self):
        self.oracle_executor.close_connection()
        self.snowflake_executor.close_connection()

    def perform_diff(self, result_id, oracle_sql, snowflake_sql):
        oracle_cols, oracle_data = self.oracle_executor.execute_query(oracle_sql)
        snowflake_cols, snowflake_data = self.snowflake_executor.execute_query(snowflake_sql)

        if oracle_cols != snowflake_cols:
            data_diff = {
                "result_id": result_id,
                "result": "Cannot perform comparison as the columns in Oracle and Snowflake queries are not same",
                "oracle_cols": oracle_cols,
                "snowflake_cols": snowflake_cols,
            }
            return

        # First column will be used as primary key
        oracle_primary_key = oracle_cols[0]
        snowflake_primary_key = snowflake_cols[0]

        data_diff = {
            "result_id": result_id,
            "primary_key": oracle_primary_key,
            "columns": oracle_cols,
            "oracle_only_rows": [],
            "snowflake_only_rows": [],
            "same_rows": [],
            "diff_rows": []
        }

        oracle_all_pks = [json_obj[oracle_primary_key] for json_obj in oracle_data]
        print(oracle_all_pks)
        snowflake_all_pks = [json_obj[snowflake_primary_key] for json_obj in snowflake_data]
        print(snowflake_all_pks)

        all_pks = list(set(oracle_all_pks + snowflake_all_pks))
        all_pks.sort()

        print(all_pks)

        for pk in all_pks:
            print(f'Comparing record with primary key {pk}')

            oracle_row = find_item_by_field(oracle_data, oracle_primary_key, pk)
            snowflake_row = find_item_by_field(snowflake_data, snowflake_primary_key, pk)

            if not oracle_row:
                data_diff["snowflake_only_rows"].append(snowflake_row)
                continue

            if not snowflake_row:
                data_diff["oracle_only_rows"].append(oracle_row)
                continue

            # Check if the rows are exactly same.
            if oracle_row == snowflake_row:
                data_diff["same_rows"].append(oracle_row)
                continue

            # Find differences
            record_diff = {
                "record_id": pk
            }

            for column_name in oracle_cols:
                print(f'Comparing column {column_name}')
                if oracle_row[column_name] != snowflake_row[column_name]:
                    record_diff[column_name] = {"oracle": oracle_row[column_name],
                                                "snowflake": snowflake_row[column_name]}

            data_diff["diff_rows"].append(record_diff)

        print(data_diff)
        print(f'Data Diff: {json.dumps(data_diff, indent=4)}')

        return data_diff


def unit_test():
    differ = QueryDiffer('config/oracle-config.yml', 'config/snowflake-config.yml')

    differ.open_connections()

    queries_to_execute = read_yaml_file('config/data-diff.yml')

    all_diffs = []
    for item in queries_to_execute:
        diff_id = item['id']
        oracle_sql = item['orcl_sql']
        snowflake_sql = item['sf_sql']

        diff = differ.perform_diff(diff_id, oracle_sql, snowflake_sql)
        all_diffs.append(diff)

    writer = DataDiffReporter()
    writer.write_diff_to_excel(all_diffs, "./output/data-diff.xlsx")

    differ.close_connections()

    return


if __name__ == '__main__':
    unit_test()
