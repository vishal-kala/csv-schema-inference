import json
import yaml

from migration_validator.db_compare.executor.snowflake_query_executor import SnowflakeQueryExecutor
from migration_validator.db_compare.reporter.masked_fields_reporter import MaskedFieldsReporter


def read_yaml_file(yaml_file):
    with open(yaml_file) as file:
        return yaml.safe_load(file)


class MaskedFieldsChecker:
    def __init__(self, snowflake_config_file, masked_fields_config_file):
        self.snowflake_config_file = snowflake_config_file
        self.snowflake_executor = SnowflakeQueryExecutor(self.snowflake_config_file)

        self.masked_fields_config_file = masked_fields_config_file
        self.table_list = read_yaml_file(masked_fields_config_file)['tables']
        self.column_list = read_yaml_file(masked_fields_config_file)['columns']

        print(f'Tables to check: {self.table_list}')
        print(f'Columns to check: {self.column_list}')

    def open_connections(self):
        self.snowflake_executor.open_connection()

    def close_connections(self):
        self.snowflake_executor.close_connection()

    def count_not_nulls(self, table, column):
        query_count_not_nulls = f'SELECT COUNT(1) AS RECORD_COUNT FROM {table} WHERE {column} IS NOT NULL'

        out_cols, out_records = self.snowflake_executor.execute_query(query_count_not_nulls)

        record_count = out_records[0]['RECORD_COUNT']

        return int(record_count)

    def execute_fields_checker(self):
        all_results = []

        for table in self.table_list:
            table_result = {"table": table, "result": []}

            # Get all column metadata for a given table.
            metadata_cols, table_metadata = self.snowflake_executor.fetch_table_metadata(table)
            table_columns = [json_obj['COLUMN_NAME'] for json_obj in table_metadata]

            print(f'Retrieved all columns from table {table}: {table_columns}')

            for column in self.column_list:
                # Check if the column is present in the table.
                if column in table_columns:
                    # Build the count query and execute
                    count_not_nulls = self.count_not_nulls(table, column)
                    if count_not_nulls == 0:
                        table_result['result'].append({"table": table, "column": column,
                                                       "count": 0, "result": "All values are null"})
                    else:
                        table_result['result'].append({"table": table, "column": column,
                                                       "count": count_not_nulls, "result": "Found not null values"})
                else:
                    table_result['result'].append({"table": table, "column": column,
                                                   "count": -1, "result": "Column not found"})

            all_results.append(table_result)

        print(f'Checker Result: {json.dumps(all_results, indent=4)}')

        return all_results


def unit_test():
    checker = MaskedFieldsChecker('config/snowflake-config.yml', 'config/masked-fields-checker.yml')

    checker.open_connections()

    result = checker.execute_fields_checker()

    print(result)

    writer = MaskedFieldsReporter()
    writer.write_data_to_excel(result, "./output/masked-fields-check.xlsx")

    checker.close_connections()

    return


if __name__ == '__main__':
    unit_test()
