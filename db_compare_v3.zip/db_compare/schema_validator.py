import json
import csv

from migration_validator.db_compare.executor.oracle_query_executor import OracleQueryExecutor
from migration_validator.db_compare.executor.snowflake_query_executor import SnowflakeQueryExecutor
from migration_validator.db_compare.reporter.schema_diff_reporter import SchemaDiffReporter

INCLUDE_MATCHING_COLUMNS = False
SNOWFLAKE_IGNORE_COLUMNS = ['IDMC_TASKRUNID', 'RAWLOADTIME', 'TABLENAME']
ORACLE_IGNORE_COLUMNS = []

ORACLE_TRANSACTION_DICT = {
    "TIMESTAMP(6)": "DATE"
}

SNOWFLAKE_TRANSACTION_DICT = {
    "TEXT": "VARCHAR2",
    "TIMESTAMP_NTZ": "DATE"
}


def read_csv_file(csv_file_path):
    with open(csv_file_path, newline='') as file:
        reader = csv.reader(file)
        tables_to_diff = []
        for row in reader:
            tables_to_diff.append(row)

    return tables_to_diff


def find_item_by_field(json_list, field_name, field_value):
    for item in json_list:
        if item.get(field_name) == field_value:
            return item
    return None


def extract_oracle_data_type(column):
    if not column:
        return None

    data_type = ORACLE_TRANSACTION_DICT.get(column['DATA_TYPE'], column['DATA_TYPE'])
    data_length = column['DATA_LENGTH']

    if data_length and data_type not in ['NUMBER', 'DATE', 'TIMESTAMP(6)']:
        return f'{data_type}({data_length})'
    else:
        return data_type


def is_oracle_nullable(column):
    if not column:
        return None

    is_nullable = column['NULLABLE']

    if is_nullable == 'Y' or is_nullable == 'YES':
        return 'Yes'

    return 'No'


def extract_snowflake_data_type(column):
    if not column:
        return None

    data_type = SNOWFLAKE_TRANSACTION_DICT.get(column['DATA_TYPE'], column['DATA_TYPE'])
    data_length = column['DATA_LENGTH']

    if data_length:
        return f'{data_type}({data_length})'
    else:
        return data_type


def is_snowflake_nullable(column):
    if not column:
        return None

    is_nullable = column['NULLABLE']

    if is_nullable == 'Y' or is_nullable == 'YES':
        return 'Yes'

    return 'No'


class SchemaValidator:
    def __init__(self, oracle_config_file, snowflake_config_file):
        self.oracle_config_file = oracle_config_file
        self.snowflake_config_file = snowflake_config_file

        self.oracle_executor = OracleQueryExecutor(self.oracle_config_file)
        self.snowflake_executor = SnowflakeQueryExecutor(self.snowflake_config_file)

    def open_connections(self):
        self.oracle_executor.open_connection()
        self.snowflake_executor.open_connection()

    def close_connections(self):
        self.oracle_executor.close_connection()
        self.snowflake_executor.close_connection()

    def perform_table_diff(self, oracle_table, snowflake_table):
        oracle_cols, oracle_table_metadata = self.oracle_executor.fetch_table_metadata(oracle_table)
        snowflake_cols, snowflake_table_metadata = self.snowflake_executor.fetch_table_metadata(snowflake_table)

        diff_response = {
            "oracle_table": oracle_table,
            "snowflake_table": snowflake_table,
            "result": None
        }

        if len(oracle_table_metadata) == 0 and len(snowflake_table_metadata) == 0:
            diff_response["result"] = "Tables not found in both side"

        elif len(oracle_table_metadata) == 0:
            diff_response["result"] = "Table not found in Oracle"

        elif len(snowflake_table_metadata) == 0:
            diff_response["result"] = "Table not found in Snowflake"
        else:
            column_diff_response = []

            oracle_columns = [json_obj['COLUMN_NAME'] for json_obj in oracle_table_metadata]
            snowflake_columns = [json_obj['COLUMN_NAME'] for json_obj in snowflake_table_metadata]

            # Remove columns to ignore from snowflake and oracle
            snowflake_columns = [i for i in snowflake_columns if i not in SNOWFLAKE_IGNORE_COLUMNS]
            oracle_columns = [i for i in oracle_columns if i not in ORACLE_IGNORE_COLUMNS]

            all_columns = list(set(oracle_columns + snowflake_columns))
            all_columns.sort()

            for column_name in all_columns:
                print(f'Comparing column {column_name}')

                oracle_column = find_item_by_field(oracle_table_metadata, 'COLUMN_NAME', column_name)
                oracle_data_type = extract_oracle_data_type(oracle_column)
                oracle_nullable = is_oracle_nullable(oracle_column)

                snowflake_column = find_item_by_field(snowflake_table_metadata, 'COLUMN_NAME', column_name)
                snowflake_data_type = extract_snowflake_data_type(snowflake_column)
                snowflake_nullable = is_snowflake_nullable(snowflake_column)

                column_diff = {
                    "name": column_name,
                    "orcl_data_type": oracle_data_type,
                    "orcl_nullable": oracle_nullable,
                    "snow_data_type": snowflake_data_type,
                    "snow_nullable": snowflake_nullable
                }

                if not oracle_column:
                    column_diff['result'] = 'Column missing from Oracle'
                    column_diff_response.append(column_diff)
                    continue

                if not snowflake_column:
                    column_diff['result'] = 'Column missing from Snowflake'
                    column_diff_response.append(column_diff)
                    continue

                if oracle_data_type != snowflake_data_type:
                    column_diff['result'] = 'Column data type mismatch'
                    column_diff_response.append(column_diff)
                    continue

                if oracle_nullable != snowflake_nullable:
                    column_diff['result'] = 'Column nullability mismatch'
                    column_diff_response.append(column_diff)
                    continue

                if oracle_data_type == snowflake_data_type \
                        and oracle_nullable == snowflake_nullable \
                        and INCLUDE_MATCHING_COLUMNS is True:
                    column_diff['result'] = ''
                    column_diff_response.append(column_diff)
                    continue

            diff_response["columns"] = column_diff_response

        return diff_response


def unit_test():
    schema_validator = SchemaValidator('config/oracle-config.yml', 'config/snowflake-config.yml')

    schema_validator.open_connections()

    tables_to_diff = read_csv_file('config/schema-diff.csv')

    all_diffs = []
    for table_names in tables_to_diff:
        all_diffs.append(schema_validator.perform_table_diff(table_names[0], table_names[1]))

    print(json.dumps(all_diffs, indent=4))

    schema_diff_reporter = SchemaDiffReporter()
    schema_diff_reporter.write_diff_to_excel(all_diffs, './output/schema-diff.xlsx')

    schema_validator.close_connections()


if __name__ == '__main__':
    unit_test()
